<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<% request.setCharacterEncoding("UTF-8"); %>
<%@ page import="dnf.전투, dnf.캐릭터, dnf.전사, dnf.마법사, dnf.플레이어, dnf.용" %>
<%
    캐릭터 c        = (캐릭터) session.getAttribute("character");
    String playerId = (String) session.getAttribute("playerId");
    용 dragon       = (용) session.getAttribute("dragon");
    String result   = null;

    if (c == null) {
        response.sendRedirect("createCharacter.jsp");
        return;
    }

    if (dragon == null) {
        dragon = new 용();
        session.setAttribute("dragon", dragon);
    }

    if ("POST".equalsIgnoreCase(request.getMethod())) {
        전투 battle = new 전투();
        result = battle.몬스터공격(playerId, c, dragon);
        session.setAttribute("dragon", dragon);
    }

    int hpPercent = dragon.getHP퍼센트();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>몬스터 공격 - 던전앤파이터</title>
</head>
<body>
<h2>[ 몬스터 공격 ]</h2>
<hr>

<h3>[ 내 캐릭터 ]</h3>
<p><b>플레이어 ID:</b> <%= playerId %></p>
<p><b>캐릭터명:</b> <%= c.get캐릭터명() %></p>
<p><b>직업:</b> <%= c.get직업() %></p>
<p><b>레벨:</b> <%= c.get레벨() %></p>
<p><b>HP:</b> <%= c.getHP() %></p>
<p><b>공격력:</b> <%= (int) c.get공격력() %></p>

<hr>

<h3>[ 붉은 용 ]</h3>
<p><b>HP:</b> <%= dragon.get현재HP() %> / <%= dragon.get최대HP() %></p>
<p>
    [
    <%
        int blocks = hpPercent / 5;
        for (int i = 0; i < 20; i++) {
            if (i < blocks) out.print("█");
            else out.print("░");
        }
    %>
    ] <%= hpPercent %>%
</p>

<hr>

<% if (dragon.생존여부()) { %>
    <form method="POST" action="attackMonster.jsp">
        <input type="submit" value="몬스터 공격!" />
    </form>
<% } else { %>
    <p><b>★ 용을 처치했습니다! 클리어! ★</b></p>
    <a href="createCharacter.jsp"><button>다시 시작</button></a>
<% } %>

<hr>

<% if (result != null) { %>
    <p><b>공격 결과:</b> <%= result %></p>
<% } %>

<br>
<a href="createCharacter.jsp">← 캐릭터 생성으로</a>
&nbsp;&nbsp;
<a href="index.jsp">← 메인으로</a>
</body>
</html>
